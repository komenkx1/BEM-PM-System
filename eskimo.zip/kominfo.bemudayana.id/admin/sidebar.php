<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo $_SESSION['username']; ?></p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>

    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MENU UTAMA</li>
      <li <?php if ($page == "dashboard") echo "class='active'"; ?>><a href="index.php"><i class="fa fa-home"></i>
          <span>Jadwal Post</span></a></li>
      <li class=" treeview">
        <a href="#">
          <i class="fa fa-cloud-upload"></i> <span>Unggah Bahan</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        
      <ul class="treeview-menu">
        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'psdm' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/10trHi-IPJ2nFrHzcZeRLnnxevevZrYta?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>PSDM</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'risbang' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1jgMM32H4bj24cjLya6GS75_yA5ENFGfH?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>RISBANG</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'mibat' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1qU2jQF0dn1O9qTPglkURad71C1dQab2e?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>MIBAT</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'admin' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1RQ4nVrSU1fGuVHWX1koNNeqB7VxHDTiG?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>KOMINFO</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'hublu' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1zSofBoO88u_VwIUcvsJMiQ2dBDeQqgNy?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>HUBLU</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'sinpus' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1aK8KTclcqvxjVh35zFXuFPM2fYnTgz6c?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>SINPUS</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'soslindup' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1ZAgw6-s5_sX2ttytCQtuLwx7jx1nEeco?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>SOSLINDUP</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'menbud' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1XSuM-ELqCCOSH7alhN5OqHqh7CeTJ5WM?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>MENBUD</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'pemdes' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/11BX-Zacrqz1-bfxqX3RSVq5tKh-EpJJz?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>PEMDES</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'kwu' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1sLGFYmqHJ1FwXwRwIy8HkRHoDWrhNytA?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>KWU</a></li>
        <?php }?>
        
        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'adkesma' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1qNnpnEpXXEiNlKlsD3fRH0bk_SN6oBTl?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>ADKESMA</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'jakda' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1n9R17So2mR9GK1yKS0kdEIaYls1xjtj-?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>JAKDA</a></li>
        <?php }?>

        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'jaknas' ) { ?>
        <li><a href="https://drive.google.com/drive/folders/1-SgE9aSNRHFUfN_oL_norPA5YsAKzFFH?usp=sharing" target="blank">
        <i class="fa fa-circle-o"></i>JAKNAS</a></li>
        <?php }?>
      
      </ul>
    </li>

  </ul>
</section>
</aside>