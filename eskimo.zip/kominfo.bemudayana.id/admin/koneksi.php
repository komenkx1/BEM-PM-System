<?php

$koneksi = mysqli_connect("localhost",  "bemudaya_kalekale", "kominforeparasi2020", "bemudaya_eskimo");

// Check connection
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>

