<?php 
 ob_start();
if ($_SESSION['role'] != 'admin') {
   header("location:index?alert=gaboleh_akses");
}
   ob_flush();
