<?php
ob_start();
session_start();

$page = 'dashboard';
include 'menu.php';
include 'sidebar.php';
include 'index.php';
require_once('koneksi.php');
$id_user = $_SESSION['id'];
$kementerian = $_SESSION['role'];

$data = mysqli_query($koneksi, "SELECT * FROM user WHERE role='$kementerian'");
$d = mysqli_fetch_array($data);

if (isset($_POST['title']) && isset($_POST['start']) && isset($_POST['end']) && isset($_POST['color']) && isset($_SESSION['role'])) {
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = $_POST['color'];
	$kementerian = $_SESSION['role'];
	$created_at = $_SESSION['tanggal_aktif'];
	$judul = $header . $title;

	$hitung = mysqli_query($koneksi, "SELECT COUNT(*) as juml FROM events WHERE start = '$start'");
	$h = mysqli_fetch_array($hitung);

	if ($h['juml'] > 5) {
		header('Location:index.php?alert=gagal-alert-lebih');
	} else {

		$tgl1    = $start; // menentukan tanggal awal
		$tgl2    = date('Y-m-d', strtotime('+3 days', strtotime($tgl1)));
		$sql = "INSERT INTO events(title, start, end, color, kementerian,created_at) values ('$judul', '$start', '$end', '$color','$kementerian','$created_at')";
		$sql2 = "UPDATE user SET tanggal_aktif='$tgl2' WHERE role='$kementerian'";

		if ($d['tanggal_aktif'] <= $tgl1) {
			echo $sql;
			$query = $koneksi->prepare($sql);

			if ($query == false) {
				print_r($koneksi->errorInfo());
				die('Erreur prepare');
			}
			$sth = $query->execute();

			if ($sth == false) {
				print_r($query->errorInfo());
				die('Erreur execute');
			}

			if ($koneksi->query($sql2) === TRUE) {
				echo "Record updated successfully";
			} else {
				echo "Error updating record: " . $koneksi->error;
			}
			$smt_after = $koneksi->prepare("SELECT * FROM user where id =$id_user");
			$smt_after->execute();
			$result = $smt_after->get_result();
			$user_after = $result->fetch_assoc();
			$_SESSION['tanggal_aktif'] = $user_after['tanggal_aktif'];
			header("Location:index.php?alert=sukses-alert");
			ob_flush();
		} else {
			header("Location:index.php?alert=gagal-alert");
		}
	}
}
