<?php
ob_start();
session_start();
require_once('koneksi.php');

$id = $_POST['id'];
$title = $_POST['title'];
$id_user = $_SESSION['id'];

$smt = $koneksi->prepare("SELECT * FROM events where id =$id");
$smt->execute();
$result = $smt->get_result();
$event = $result->fetch_assoc();
$kementerian = $event['kementerian'];

$smt2 = $koneksi->prepare("SELECT * FROM events ORDER BY id DESC LIMIT 1");
$smt2->execute();
$result2 = $smt2->get_result();
$event_terbaru =  $result2->fetch_assoc();

if ($event['kementerian'] == $_SESSION['role'] || $_SESSION['role'] == 'admin') {

	if (isset($_POST['terposting']) && !isset($_POST['delete'])) {
		$sql = "UPDATE events SET  status = 'terposting', title = '$title' WHERE id = $id ";
		header('Location:index.php?alert=success-terposting');
	} elseif (isset($_POST['delete']) && !isset($_POST['terposting']) || isset($_POST['terposting'])) {

		if ($event['created_at'] < $event_terbaru['created_at']) {
			header("Location:index.php?alert=gagal-delete");
		} else {
			// echo $kementerian;
			$tgl1    = $event['created_at'];
			$tgl2    = date('Y-m-d', strtotime($tgl1));
			$sql2 = "UPDATE user SET tanggal_aktif='$tgl2' WHERE role='$kementerian'";
			$sql = "DELETE FROM events WHERE id = $id";
			$query2 = $koneksi->prepare($sql2);
			if ($query2 == false) {
				print_r($koneksi->errorInfo());
				die('Erreur prepare');
			}
			$sth2 = $query2->execute();
			if ($sth2 == false) {
				print_r($query->errorInfo());
				die('Erreur execute');
			}
			header('Location:index.php?alert=success-delete');
		}
	} elseif (!isset($_POST['terposting'])) {
		$sql = "UPDATE events SET  status = 'terdaftar', title = '$title' WHERE id = $id ";
		header('Location:index.php?alert=sukses-update');
	}
} else {
	header('Location: index.php');
}

$query = $koneksi->prepare($sql);
if ($query == false) {
	print_r($koneksi->errorInfo());
	die('Erreur prepare');
}
$sth = $query->execute();
if ($sth == false) {
	print_r($query->errorInfo());
	die('Erreur execute');
}

$smt_after = $koneksi->prepare("SELECT * FROM user where id =$id_user");
$smt_after->execute();
$result = $smt_after->get_result();
$user_after = $result->fetch_assoc();
$_SESSION['tanggal_aktif'] = $user_after['tanggal_aktif'];
// header('Location: index.php');

ob_flush();
