<?php
$page = 'E-Sistem Kalender Kominfo';
include 'menu.php';
include 'sidebar.php';
include 'koneksi.php';
require_once('koneksi.php');
$role = $_SESSION['role'];
$nama = $_SESSION['nama'];
$aktif = $_SESSION['tanggal_aktif'];

?>

<!-- Left side column. contains the logo and sidebar -->
<script src='js/validation.js'></script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo $nama; ?>
      <h4>Anda bisa posting tanggal <?php echo date('d/m/Y', strtotime($aktif)); ?> dan setelahnya</h4>
    </h1>

    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Upload </li>
    </ol>
  </section>

  <!-- warninggggggggg -->
  <section class="content">
    <?php
    if (isset($_GET['alert'])) {
      if ($_GET['alert'] == "sukses-login") {
    ?>

        <div class="alert alert-info">
          Selamat Datang <strong><?php echo $nama; ?></strong>
        </div>

      <?php
      } elseif ($_GET['alert'] == "gaboleh_akses") {
      ?>
        <div class="alert alert-warning">
          <strong>Warning!</strong>Maaf Anda Bukan Admin!
        </div>
      <?php

      } elseif ($_GET['alert'] == "gagal-alert") {
      ?>
        <div class="alert alert-danger">
          <strong>Gagal,</strong> Harap Input Di H+3 Dari Hari Booking Terakhir!
        </div>
      <?php
      } elseif ($_GET['alert'] == "gagal-delete") {
      ?>
        <div class="alert alert-danger">
          <strong>Gagal,</strong> Harap Hapus Postingan Terbaru Terlebih Dahulu!
        </div>
      <?php
      } elseif ($_GET['alert'] == "success-delete") {
        ?>
          <div class="alert alert-danger">
            <strong>Berhasil,</strong>Data Telah Dihapus
          </div>
        <?php
        } elseif ($_GET['alert'] == "sukses-alert") {
      ?>
        <div class="alert alert-success">
          <strong>Berhasil,</strong> Booking Postingan Telah Dibuat!
        </div>
      <?php
      }elseif ($_GET['alert'] == "sukses-update") {
        ?>
          <div class="alert alert-success">
            <strong>Berhasil,</strong> Data Telah Diupdate
          </div>
        <?php
        }elseif ($_GET['alert'] == "success-terposting") {
        ?>
          <div class="alert alert-info">
            <strong>Berhasil,</strong> Data Telah Tertandai Sebagai Terposting
          </div>
        <?php
        }elseif ($_GET['alert'] == "unset-terposting") {
          ?>
            <div class="alert alert-warning">
              <strong>Warning,</strong> Data Telah Tertandai Sebagai Belum Terposting
            </div>
          <?php
          } elseif ($_GET['alert'] == "gagal-alert-lebih") {
      ?>
        <div class="alert alert-danger">
          <strong>Gagal,</strong> Events maksimal 6!
        </div>
    <?php
      }
    }
    ?>

    <!-- Info boxes -->
    <div class="row">
      <div class="clearfix visible-sm-block"></div>
    </div>

    <div class="box">
      <div class="box-header">
        <div class="row">
          <div class="col-lg-12 text-center">
            <div id="calendar" class="col-centered">
            </div>
          </div>
        </div>
      </div>
  </section>

  <section class="content">
    <div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form class="form-horizontal" method="POST" action="addEvent.php">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="myModalLabel">Tambah Postingan</h4>
              <h5 class="text-muted" id="myModalLabel">Format Judul : Judul Postingan_Waktu Post [TANPA NAMA KEMENTERIAN]</h5>
              <h5 class="text-muted" id="myModalLabel">Contoh : Ramalan_17.00 atau Beasiswa Gudang Garam_15.00</h5>
            </div>

            <div class="modal-body">
              <div class="form-group">
                <label for="title" class="col-sm-2 control-label">Judul</label>
                <?php
                if ($role == "psdm") {
                  $header = "PSDM_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "risbang") {
                  $header = "RISBANG_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "mibat") {
                  $header = "MIBAT_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "admin") {
                  $header = "KOMINFO_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "hublu") {
                  $header = "HUBLU_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "sinpus") {
                  $header = "SINPUS_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "soslindup") {
                  $header = "SOSLINDUP_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "menbud") {
                  $header = "MENBUD_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "pemdes") {
                  $header = "PEMDES_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "kwu") {
                  $header = "KWU_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "adkesma") {
                  $header = "ADKESMA";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "jakda") {
                  $header = "JAKDA_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                } elseif ($role == "jaknas") {
                  $header = "JAKNAS_";
                ?>
                  <div class="col-sm-10">
                    <input type="text" name="title" class="form-control" id="formTitle" placeholder="Judul Postingan">
                  </div>

                <?php
                }
                ?>
              </div>

              <div class="form-group">
                <?php
                if ($role == "psdm") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#0278ae;" name="color" class="form-control" value="#0278ae"></input>
                  </div>

                <?php
                } else if ($role == "risbang") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#43658b;" name="color" class="form-control" value="#43658b"></input>
                  </div>

                <?php
                } else if ($role == "mibat") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#51adcf;" name="color" class="form-control" value="#51adcf"></input>
                  </div>

                <?php
                } else if ($role == "admin") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#ffc30b;" name="color" class="form-control" value="#ffc30b"></input>
                  </div>

                <?php
                } else if ($role == "hublu") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#e0b01d;" name="color" class="form-control" value="#ffc30b"></input>
                  </div>

                <?php
                } else if ($role == "sinpus") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#e6ca17;" name="color" class="form-control" value="#ffc30b"></input>
                  </div>

                <?php
                } else if ($role == "soslindup") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#519872;" name="color" class="form-control" value="#519872"></input>
                  </div>

                <?php
                } else if ($role == "menbud") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#197163;" name="color" class="form-control" value="#197163"></input>
                  </div>

                <?php
                } else if ($role == "pemdes") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#158467;" name="color" class="form-control" value="#158467"></input>
                  </div>

                <?php
                } else if ($role == "kwu") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#065446;" name="color" class="form-control" value="#065446"></input>
                  </div>

                <?php
                } else if ($role == "adkesma") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#ce6262;" name="color" class="form-control" value="#ce6262"></input>
                  </div>

                <?php
                } else if ($role == "jakda") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#f05454;" name="color" class="form-control" value="#f05454"></input>
                  </div>

                <?php
                } else if ($role == "jaknas") {
                ?>
                  <div class="col-sm-10">
                    <input id="color" readonly type="hidden" style="color:#af2d2d;" name="color" class="form-control" value="#af2d2d"></input>
                  </div>

                <?php
                }
                ?>

              </div>

              <div class="form-group">
                <label for="start" class="col-sm-2 control-label">Start date</label>
                <div class="col-sm-10">
                  <input type="text" name="start" class="form-control" id="start" readonly="readonly">
                </div>
              </div>

              <div class="form-group">
                <label for="end" class="col-sm-2 control-label">End date</label>
                <div class="col-sm-10">
                  <input type="text" name="end" class="form-control" id="end">
                </div>
              </div>

              <div class="form-group">
                <div class="col-sm-10">
                  <input readonly="readonly" type="hidden" name="kementerian" class="form-control" id="kementerian" value="<?php echo $nama; ?>">
                </div>
              </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-primary" id="submitForm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>


  </section>
</div>
<?php include 'footer.php' ?>

<!-- Modal -->
<div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">

    <div class="modal-content">
      <form class="form-horizontal" method="POST" action="editEventTitle.php">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Edit Jadwal</h4>
        </div>

        <div class="modal-body">
          <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Judul</label>
            <div class="col-sm-10">
              <input type="text" name="title" class="form-control" id="title" placeholder="Title">
             <small class="text-danger" id="denied" >* Anda Tidak Dapat Melakukan Edit Pada Item Ini</small>

            </div>
          </div>
           <div class="form-group"  style="display: none;" id="statuscheck">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="checkbox">
                <label class="text-info" ><input id="status" type="checkbox" name="terposting"> Tandai Sudah Ter-posting</label>
              </div>
            </div>
          </div>
            <div class="form-group" style="display: none;" id="delete">
              <div class="col-sm-offset-2 col-sm-10">
                <div class="checkbox">
                  <label class="text-danger" ><input  type="checkbox" name="delete" value="delete"> Delete event</label>
                  <small class="d-none" style="display: none;">* Harap Menghapus Postingan Terbaru Sebelum Menghapus Postingan ini</small>
                </div>
              </div>
            </div>
      

          <input type="hidden" name="id" class="form-control" id="id">
        </div>


        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>