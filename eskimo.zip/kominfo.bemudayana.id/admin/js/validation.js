
let submit = document.querySelector('#submitButton');

submit.addEventListener('onclick', ()=>{
   //validate text
   let ft = document.querySelector('#formTitle');
   if(ft.value == ""){
       alert('Judul event harus diisi!');
   }
});