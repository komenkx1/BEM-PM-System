<?php
  ob_start();
// Connexion à la base de données
require_once('koneksi.php');

if (isset($_POST['Event'][0]) && isset($_POST['Event'][1]) && isset($_POST['Event'][2])) {


	$id = $_POST['Event'][0];
	$start = $_POST['Event'][1];
	$end = $_POST['Event'][2];

	$query = "UPDATE events SET  start = ?, end = ? WHERE id = ? ";
	$smt = $koneksi->prepare($query);
	$smt->bind_param('ssi', $start, $end, $id);

	if ($smt->execute()) {
		die('OK');
	} else {
		print_r($smt->error);
		die('Erreur execute');
	}
}
//header('Location: '.$_SERVER['HTTP_REFERER']);
  ob_flush();