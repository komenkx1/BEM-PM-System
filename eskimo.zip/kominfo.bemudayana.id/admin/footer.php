<footer class="main-footer">
  <strong>Copyright &copy; 2021 <a href="https://bemudayana.id/">KOMINFO BEM PM UDAYANA</a>.</strong> All rights
  reserved.
</footer>

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>

<!-- Core plugin JavaScript-->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<script src="https://channime.com/assets/back/vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- CK Editor -->
<script src="bower_components/ckeditor/ckeditor.js"></script>

<!-- Datatables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.7/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js "></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>

<!-- AdminLTE App -->
<!-- fullCalendar -->
<script src="bower_components/moment/moment.js"></script>
<script src="bower_components/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>


<script src="js/app.js"></script>

<script>
  $(document).ready(function() {

    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,basicWeek,basicDay'
      },

      editable: false,
      eventLimit: 6, // allow "more" link when too many events
      eventLimitText: 'Slot sudah penuh!',
      selectable: true,
      selectHelper: true,
      select: function(start, end) {

        $('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
        $('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
        $('#ModalAdd').modal('show');
      },
      eventRender: function(event, element) {
        element.bind('dblclick', function() {
          $('#ModalEdit #id').val(event.id);
          $('#ModalEdit #title').val(event.title);
          $('#ModalEdit #color').val(event.color);
          $('#ModalEdit #color').val(event.color);
          if (event.status == 'terposting') {
            $('#status').prop('checked', true);
          }
          if (event.kementerian == event.logged && event.tanggal_old < event.tanggal_terbaru) {
            $('small').css("display", "block");
          }else{
            $('small').css("display", "none");

          }
           if (event.kementerian == event.logged || event.logged == 'admin') {
            $('small#denied').css("display", "none");
            $('#delete').css("display", "block");
            $('input#title').removeAttr('disabled');
            $('#statuscheck').css("display", "block");
            
          }else{
            $('small#denied').css("display", "block");
           
            $('input#title').attr('disabled', 'disabled');
            $('#delete').css("display", "none");
            $('#statuscheck').css("display", "none");

          }
          $('#ModalEdit').modal('show');
        });
      },
      eventDrop: function(event, delta, revertFunc) { // si changement de position

        edit(event);

      },
      eventResize: function(event, dayDelta, minuteDelta, revertFunc) { // si changement de longueur

        edit(event);

      },

      events: [
        <?php
        $smt = $koneksi->prepare("SELECT * FROM events");
        $smt->execute();
        $result = $smt->get_result();

        $smt2 = $koneksi->prepare("SELECT * FROM events ORDER BY id DESC LIMIT 1");
        $smt2->execute();
        $result2 = $smt2->get_result();
        $event_terbaru =  $result2->fetch_assoc();

        while ($event = $result->fetch_assoc()) {

          $start = explode(" ", $event['start']);
          $end = explode(" ", $event['end']);
          if ($start[1] == '00:00:00') {
            $start = $start[0];
          } else {
            $start = $event['start'];
          }
          if ($end[1] == '00:00:00') {
            $end = $end[0];
          } else {
            $end = $event['end'];
          }
        ?> {
            id: '<?php echo $event['id']; ?>',
            logged: '<?php echo $_SESSION['role']; ?>',
            kementerian: '<?php echo $event['kementerian']; ?>',
            title: '<?php echo $event['title']; ?>',
            start: '<?php echo $start; ?>',
            end: '<?php echo $end; ?>',
            status: '<?php echo $event['status']; ?>',
            tanggal_terbaru: '<?php echo $event_terbaru['created_at']; ?>',
            tanggal_old: '<?php echo $event['created_at']; ?>',
            color: '<?php if ($event['status'] == 'terposting') {echo ('black');} else { echo $event['color'];} ?>',
          },
        <?php } ?>
      ]
    });

    function edit(event) {
      start = event.start.format('YYYY-MM-DD HH:mm:ss');
      if (event.end) {
        end = event.end.format('YYYY-MM-DD HH:mm:ss');
      } else {
        end = start;
      }

      id = event.id;

      Event = [];
      Event[0] = id;
      Event[1] = start;
      Event[2] = end;

      $.ajax({
        url: 'editEventDate.php',
        type: "POST",
        data: {
          Event: Event
        },
        success: function(rep) {
          if (rep == 'OK') {
            alert('Saved');
          } else {
            alert('event telah di pindahkan');
          }
        }
      });
    }

  });
</script>

</body>

</html>