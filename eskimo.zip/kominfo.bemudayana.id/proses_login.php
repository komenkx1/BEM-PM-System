<?php
ob_start();
include 'admin/koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$stmt = $koneksi->prepare('SELECT tanggal_aktif, nama,id, role FROM user WHERE username=? and password=?');
$stmt->bind_param('ss', $username, $password);

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
	$user = $result->fetch_assoc();
		session_start();
		$_SESSION['username'] = $username;
		$_SESSION['role'] = $user['role'];
		$_SESSION['nama'] = $user['nama'];
		$_SESSION['id'] = $user['id'];
		$_SESSION['tanggal_aktif'] = $user['tanggal_aktif'];
		$_SESSION['status'] = "login";
	header("location:admin/index.php?alert=sukses-login");
} else {
	header("location:login.php?alert=gagal-login");
}
ob_flush();