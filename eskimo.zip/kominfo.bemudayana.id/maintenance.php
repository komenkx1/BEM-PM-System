<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="theme-color" content="#3ed2a7">
<link rel="shortcut icon" href="favicon.png" />
<title>Eskimo - BEM Udayana</title>
<link rel="stylesheet" href="../use.typekit.net/qxb8htk.css">
<link rel="stylesheet" href="assets/vendors/liquid-icon/liquid-icon.min.css" />
<link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" href="assets/css/theme-vendors.min.css" />
<link rel="stylesheet" href="assets/css/theme.min.css" />
<link rel="stylesheet" href="assets/css/themes/original.css" />

<script async src="assets/vendors/modernizr.min.js"></script>
</head>
<body data-mobile-nav-trigger-alignment="right" data-mobile-nav-align="left" data-mobile-nav-style="modern" data-mobile-nav-shceme="gray" data-mobile-header-scheme="gray" data-mobile-nav-breakpoint="1199">
<div id="wrap">
<main id="content" class="content">
<section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 bg-cover" style="background-image: url(bg-51.jpg);">
<div class="ld-particles-container pos-abs" style="height: 50vh; top: 25vh;">
<div class="ld-particles-inner pos-abs" id="particles-1" data-particles="true" data-particles-options='{"particles":{"number":{"value":150},"color":{"value":"#ffffff"},"shape":{"type":["circle"]},"opacity":{"value":0.5,"random":true,"anim":{"enable":true,"opacity_min":0.25,"speed":0,"sync":true}},"size":{"value":2,"random":true,"anim":{"enable":true,"size_min":35}},"move":{"enable":true,"direction":"right","speed":6,"random":true,"out_mode":"out","attract":{"enable":true}}},"interactivity":{"modes":{"bubble":{"distance":1,"size":1,"duration":1}}},"retina_detect":true}'>
</div>
</div>
<div class="ld-particles-container pos-abs" style="height: 50vh; top: 25vh;">
<div class="ld-particles-inner" id="particles-2" data-particles="true" data-particles-options='{"particles":{"number":{"value":100},"color":{"value":"#ffffff"},"shape":{"type":["circle"]},"opacity":{"value":0.65,"random":true,"anim":{"enable":true,"opacity_min":0.2,"speed":1,"sync":true}},"size":{"value":2,"random":true,"anim":{"enable":true,"size_min":44}},"move":{"enable":true,"direction":"right","speed":4,"random":true,"out_mode":"out","attract":{"enable":true}}},"interactivity":{"modes":{"bubble":{"distance":1,"size":1,"duration":1}}},"retina_detect":true}'></div>
</div>
<div class="container">
<div class="row">
<div class="lqd-column col-md-12 text-center">
<h1 class="my-0 text-white text-uppercase" data-fittext="true" data-fittext-options='{"compressor":1,"maxFontSize": 100,"minFontSize": 68}'>
Under Maintenance
</h1>
<p class="font-size-20 text-white">We will be back with new and exciting feature!</p>
<div class="mb-100"></div>
<p>Copyright 2020 <span class="text-white">KOMINFO</span>. BEM PM Universitas Udayana.</p>
</div>
</div>
</div>
</div>
</div>
</section>
</main>
</div>
<script src="assets/vendors/jquery.min.js"></script>
<script src="assets/js/theme-vendors.js"></script>
<script src="assets/js/theme.min.js"></script>
<script src="assets/js/liquidAjaxMailchimp.min.js"></script>
</body>

<!-- Mirrored from avehtml.liquid-themes.com/page-coming-soon.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Aug 2020 08:04:33 GMT -->
</html>